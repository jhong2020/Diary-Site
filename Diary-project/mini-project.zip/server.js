
// const express = require('express');
// const session = require('express-session');
// const bodyParser = require('body-parser');
// const { MongoClient, ObjectId } = require('mongodb');

// const app = express();
// const PORT = process.env.PORT || 8080;

// // MongoDB 연결 정보
// const url = 'mongodb+srv://admin:73531959@cluster0.ultg1uw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
// let db;

// // MongoDB 연결
// MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
//     .then(client => {
//         console.log('MongoDB에 연결되었습니다.');
//         db = client.db('diary');
//     })
//     .catch(error => console.error('MongoDB 연결 오류:', error));

// // Middleware 설정
// app.use(express.static('public'));
// app.use(bodyParser.urlencoded({ extended: true }));
// app.set('view engine', 'ejs');

// // 세션 미들웨어 설정
// app.use(session({
//     secret: 'secret_key', // 세션 암호화에 사용할 비밀 키
//     resave: false,
//     saveUninitialized: true
// }));

// // 홈페이지 라우트
// app.get('/', (req, res) => {
//     res.redirect('/list');
// });

// // 일기 목록 조회
// app.get('/list', async (req, res) => {
//     try {
//         let result = await db.collection('post').find().toArray();
//         res.render('list.ejs', { posts: result });
//     } catch (e) {
//         console.log(e);
//         res.status(500).send('서버 error');
//     }
// });

// // 일기 상세 조회
// app.get('/detail/:id', async (req, res) => {
//     try {
//         const diary = await db.collection('post').findOne({ _id: ObjectId(req.params.id) });
//         res.render('detail', { diary });
//     } catch (e) {
//         console.log(e);
//         res.status(500).send('서버 error');
//     }
// });

// // 일기 추가 페이지
// app.get('/write', (req, res) => {
//     res.render('write.ejs', { posts: [] }); // posts 변수를 빈 배열로 전달
// });

// // 일기 추가
// app.post('/add', async (req, res) => {
//     try {
//         const { title, content } = req.body;
//         await db.collection('post').insertOne({ title, content });
//         res.redirect('/list');
//     } catch (e) {
//         console.log(e);
//         res.status(500).send('서버 error');
//     }
// });

// // 일기 수정 페이지
// app.get('/edit/:id', async (req, res) => {
//     try {
//         const result = await db.collection('post').findOne({ _id: new ObjectId(req.params.id) });
//         if (!result) {
//             res.status(404).send('일기를 찾을 수 없습니다.');
//             return;
//         }
//         res.render('edit', { diary: result });
//     } catch (error) {
//         console.error(error);
//         res.status(500).send('서버 오류가 발생했습니다.');
//     }
// });

// // 일기 수정
// app.post('/edit/:id', async (req, res) => {
//     try {
//         const { title, content } = req.body;
//         await db.collection('post').updateOne({ _id: ObjectId(req.params.id) }, { $set: { title, content } });
//         res.redirect('/list');
//     } catch (e) {
//         console.log(e);
//         res.status(500).send('서버 error');
//     }
// });

// // 일기 삭제
// app.delete('/delete', async (req, res) => { 
//     console.log(req.query) 
//     await db.collection('post').deleteOne({ _id: new ObjectId(req.query.docid) }) 
//     res.send('삭제완료') 
// });

// // 로그인 라우트
// app.post('/login', (req, res) => {
//     const { username, password } = req.body;

//     // 여기에 사용자 인증 로직을 추가합니다.
//     // 예를 들어, 사용자가 올바른 사용자 이름과 비밀번호를 입력했는지 확인할 수 있습니다.

//     // 사용자 인증이 성공하면 세션에 사용자 정보를 저장합니다.
//     req.session.username = username;

//     // 로그인 후에는 홈페이지로 리다이렉트합니다.
//     res.redirect('/');
// });

// // 사용자가 로그인되어 있는지 확인하는 미들웨어
// function requireLogin(req, res, next) {
//     if (req.session.username) {
//         next(); // 다음 미들웨어로 이동
//     } else {
//         res.redirect('/login'); // 로그인 페이지로 리다이렉트
//     }
// }

// // 일기 목록 조회 페이지에 사용자 인증 미들웨어를 추가합니다.
// app.get('/list', requireLogin, async (req, res) => {
//     // 일기 목록 조회 코드를 여기에 추가합니다.
// });

// // 서버 시작
// app.listen(PORT, () => {
//     console.log(`서버가 http://localhost:${PORT} 에서 실행중입니다.`);
// });

const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://admin:73531959@cluster0.ultg1uw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', { useNewUrlParser: true, useUnifiedTopology: true });


const diarySchema = new mongoose.Schema({
    title: String,
    content: String
});

const Diary = mongoose.model('Diary', diarySchema);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('main');
});

app.get('/diary', async (req, res) => {
    try {
        const foundDiaries = await Diary.find({});
        res.render('diary', { diaries: foundDiaries });
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 불러오는 동안 오류가 발생했습니다.");
    }
});

app.get('/list', async (req, res) => {
    try {
        const foundDiaries = await Diary.find({});
        res.render('list', { diaries: foundDiaries });
    } catch (err) {
        console.log(err); 
        res.status(500).send("일기를 불러오는 동안 오류가 발생했습니다.");
    }
});


app.get('/diary/:id', async (req, res) => {
    try {
        const diary = await Diary.findById(req.params.id);
        if (!diary) {
            return res.status(404).send("일기를 찾을 수 없습니다.");
        }
        res.render('diaryDetail', { diary: diary });
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 불러오는 동안 오류가 발생했습니다.");
    }
});


// 검색 결과 페이지 라우트
app.get('/search', async (req, res) => {
    const keyword = req.query.keyword;

    try {
        const foundDiaries = await Diary.find({ $or: [{ title: { $regex: keyword, $options: 'i' } }, { content: { $regex: keyword, $options: 'i' } }] });
        res.render('search', { keyword: keyword, diaries: foundDiaries }); // diaries 변수를 함께 전달
    } catch (err) {
        console.log(err);
        res.status(500).send("검색하는 동안 오류가 발생했습니다.");
    }
});



// 수정 페이지 라우트
app.get('/edit/:id', async (req, res) => {
    try {
        const diary = await Diary.findById(req.params.id);
        res.render('edit', { diary: diary });
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 불러오는 동안 오류가 발생했습니다.");
    }
});

// 수정 처리 라우트
app.post('/edit/:id', async (req, res) => {
    try {
        const { title, content } = req.body;
        await Diary.findByIdAndUpdate(req.params.id, { title: title, content: content });
        res.redirect('/diary');
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 수정하는 동안 오류가 발생했습니다.");
    }
});

// 삭제 처리 라우트
app.get('/delete/:id', async (req, res) => {
    try {
        await Diary.findOneAndDelete({ _id: req.params.id });
        res.redirect('/diary');
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 삭제하는 동안 오류가 발생했습니다.");
    }
});

app.get('/write', (req, res) => {
    res.render('write');
});

app.post('/write', async (req, res) => { // async 키워드 추가
    const { title, content } = req.body;

    const newDiary = new Diary({
        title: title,
        content: content
    });

    try { // try-catch 블록 추가
        await newDiary.save(); // save 메서드 앞에 await 키워드 추가
        res.redirect('/diary');
    } catch (err) {
        console.log(err);
        res.status(500).send("일기를 저장하는 동안 오류가 발생했습니다.");
    }
});

app.listen(3000, () => {
    console.log('서버가 http://localhost:3000 에서 실행중입니다.');
});
